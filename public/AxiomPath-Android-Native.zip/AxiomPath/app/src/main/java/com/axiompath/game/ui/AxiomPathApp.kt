package com.axiompath.game.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.axiompath.game.model.Checkpoint
import com.axiompath.game.model.GridCoord

@Composable
fun AxiomPathApp() {
    var currentScreen by remember { mutableStateOf("HOME") }
    var currentLevel by remember { mutableStateOf(1) }
    val completedLevels = remember { mutableStateMapOf<Int, Int>() }

    if (currentScreen == "HOME") {
        HomeScreen(
            currentLevel = currentLevel,
            completedLevels = completedLevels,
            onPlay = { level ->
                currentLevel = level
                currentScreen = "GAME"
            }
        )
    } else {
        GameScreen(
            levelNumber = currentLevel,
            onBack = { currentScreen = "HOME" },
            onLevelWon = { stars ->
                completedLevels[currentLevel] = stars
                if (currentLevel < 100) {
                    currentLevel++
                }
                currentScreen = "HOME"
            }
        )
    }
}

@Composable
fun HomeScreen(
    currentLevel: Int,
    completedLevels: Map<Int, Int>,
    onPlay: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAF9F6))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // App Title
        Text(
            text = "Axiom Path",
            fontSize = 30.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF1E254A)
        )
        Text(
            text = "Daily Mind & Logic Path Puzzle",
            fontSize = 13.sp,
            color = Color(0xFF6B7280),
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // Hero Next Level Card
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "NEXT ADVENTURE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF4F46E5)
                )
                Text(
                    text = "Level $currentLevel",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF1E254A),
                    modifier = Modifier.padding(vertical = 6.dp)
                )

                Button(
                    onClick = { onPlay(currentLevel) },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Text(text = "Play Level $currentLevel", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Levels List
        Text(
            text = "Adventure Map (100 Levels)",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1E254A),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        )

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(100) { index ->
                val level = index + 1
                val isUnlocked = level <= currentLevel
                val isCompleted = completedLevels.containsKey(level)

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isUnlocked) Color.White else Color(0xFFF3F4F6)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(enabled = isUnlocked) { onPlay(level) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Level $level",
                                fontWeight = FontWeight.Bold,
                                color = if (isUnlocked) Color(0xFF1E254A) else Color(0xFF9CA3AF)
                            )
                            Text(
                                text = when {
                                    level <= 25 -> "Meadow · 5×5 Grid"
                                    level <= 50 -> "Canyon · 6×6 Grid"
                                    level <= 75 -> "Lagoon · 6×6 Grid"
                                    else -> "Summit · 7×7 Grid"
                                },
                                fontSize = 12.sp,
                                color = Color(0xFF6B7280)
                            )
                        }

                        if (isCompleted) {
                            Text(text = "⭐ Cleared", fontSize = 12.sp, color = Color(0xFFD97706), fontWeight = FontWeight.Bold)
                        } else if (isUnlocked) {
                            Text(text = "▶ Play", fontSize = 12.sp, color = Color(0xFF4F46E5), fontWeight = FontWeight.Bold)
                        } else {
                            Text(text = "🔒", fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GameScreen(
    levelNumber: Int,
    onBack: () -> Unit,
    onLevelWon: (Int) -> Unit
) {
    val size = if (levelNumber <= 25) 5 else if (levelNumber <= 75) 6 else 7
    val checkpoints = remember(levelNumber) {
        listOf(
            Checkpoint(1, 0, 0),
            Checkpoint(2, 0, size - 1),
            Checkpoint(3, size - 1, size - 1),
            Checkpoint(4, size - 1, 0)
        )
    }

    var path by remember(levelNumber) { mutableStateOf(listOf(GridCoord(0, 0))) }
    val totalPlayable = size * size
    val isComplete = path.size == totalPlayable

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFAF9F6))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5E7EB))
            ) {
                Text("← Back", color = Color(0xFF1E254A), fontWeight = FontWeight.Bold)
            }
            Text(
                text = "Level $levelNumber",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color(0xFF1E254A)
            )
            Button(
                onClick = { path = listOf(GridCoord(0, 0)) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE5E7EB))
            ) {
                Text("Reset", color = Color(0xFF1E254A), fontWeight = FontWeight.Bold)
            }
        }

        // Progress Pill
        Row(
            modifier = Modifier
                .padding(vertical = 12.dp)
                .background(Color(0xFFEEF2FF), RoundedCornerShape(12.dp))
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Progress: ${path.size}/$totalPlayable cells",
                color = Color(0xFF4F46E5),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
        }

        // Game Grid
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .background(Color.White, RoundedCornerShape(24.dp))
                .border(2.dp, Color(0xFFE5E7EB), RoundedCornerShape(24.dp))
                .padding(8.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                for (r in 0 until size) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        for (c in 0 until size) {
                            val coord = GridCoord(r, c)
                            val pathIndex = path.indexOf(coord)
                            val isPath = pathIndex != -1
                            val isHead = path.lastOrNull() == coord
                            val cp = checkpoints.find { it.r == r && it.c == c }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .padding(3.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(
                                        when {
                                            isHead -> Color(0xFF4F46E5)
                                            isPath -> Color(0xFFC7D2FE)
                                            cp != null -> Color(0xFFEEF2FF)
                                            else -> Color(0xFFF9FAFB)
                                        }
                                    )
                                    .clickable {
                                        if (isPath && coord != path.lastOrNull()) {
                                            path = path.subList(0, pathIndex + 1)
                                        } else if (!isPath) {
                                            val last = path.last()
                                            val isAdjacent = (Math.abs(last.r - r) + Math.abs(last.c - c)) == 1
                                            if (isAdjacent) {
                                                path = path + coord
                                            }
                                        }
                                    },
                                contentAlignment = Alignment.Center
                            ) {
                                if (cp != null) {
                                    Text(
                                        text = "${cp.number}",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 14.sp,
                                        color = if (isHead) Color.White else if (isPath) Color(0xFF1E254A) else Color(0xFF4F46E5)
                                    )
                                } else if (isHead) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Win Banner
        AnimatedVisibility(visible = isComplete) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "🎉 Level Complete!",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 20.sp,
                        color = Color(0xFF065F46)
                    )
                    Text(
                        text = "You connected every cell in pure harmony!",
                        fontSize = 12.sp,
                        color = Color(0xFF047857),
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Button(
                        onClick = { onLevelWon(3) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Text("Continue Journey", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
